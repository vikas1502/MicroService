package com.ibm.myfirstdemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SimpleController {
	
	@GetMapping("/simple")
	public String message() {
		return "welcome docker";
	}

}
