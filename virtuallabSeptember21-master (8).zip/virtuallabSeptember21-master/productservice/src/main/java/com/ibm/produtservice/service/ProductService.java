package com.ibm.produtservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.produtservice.dto.ProductDTO;
import com.ibm.produtservice.entity.Product;
import com.ibm.produtservice.mapper.ProductMapper;
import com.ibm.produtservice.respository.ProductRepository;
import com.ibm.produtservice.restclient.TaxClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class ProductService {
	
		
	@Autowired
	ProductRepository productRepository;
	
	final TaxClient taxClient;
	
	@Autowired
	public ProductService(TaxClient taxClient) {
		this.taxClient=taxClient;
	}
	
	public Product createProduct(ProductDTO dto) {
		
		ProductMapper mapper=new ProductMapper();
		Product produt=mapper.convertToEntity(dto);
		return productRepository.save(produt);
		
	}
	
	@HystrixCommand(fallbackMethod="taxServiceFallback")
	public ProductDTO getProduct(Long id) {
	  Optional<Product> product=	productRepository.findById(id);
	  ProductMapper mapper=new ProductMapper();
	ProductDTO dto= mapper.convertToDto(product.get());
	Double tax= taxClient.tax(dto.getProductName());
	dto.setTax(tax);
	
	return dto;
	  
	}
	
	
	public ProductDTO byName(String name) {
		
		 Product product=	productRepository.findByProductName(name);
		 ProductMapper mapper=new ProductMapper();
			ProductDTO dto= mapper.convertToDto(product);
			Double tax= taxClient.tax(dto.getProductName());
			dto.setTax(tax);
			
			return dto;
	} 
	public ProductDTO taxServiceFallback(Long id) {
		
		Optional<Product> product=	productRepository.findById(id);
		ProductDTO productDto=null;
		if(product.isPresent()) {
			 ProductMapper mapper=new ProductMapper();
			 productDto= mapper.convertToDto(product.get());
			 productDto.setTax(8.0);
			
		}
		return productDto;
	}
	public void deleteProduct(Long id) {

		productRepository.deleteById(id);
	
		Optional<Product> entity=productRepository.findById(id);
		if(entity.isPresent()) {
		productRepository.deleteById(id);
		}else {
			
		}
	}



}
