package com.ibm.produtservice.mapper;

import com.ibm.produtservice.dto.ProductDTO;
import com.ibm.produtservice.entity.Product;

public class ProductMapper {
	
	public Product convertToEntity(ProductDTO dto) {
		
		Product entity=new Product();
		entity.setProductName(dto.getProductName());
		entity.setQuantity(dto.getQuantity());
		return entity;
	}
	
	public ProductDTO convertToDto(Product product) {
		
		ProductDTO dto=new ProductDTO();
		dto.setId(product.getId());
		dto.setProductName(product.getProductName());
		dto.setQuantity(product.getQuantity());
		return dto;
	}

}
